# VENAMCUTER AI — Local Starter

## Kya kaam karta hai
- Browser dashboard with red + black theme and @halcyon_011
- Local video upload (MP4/MOV/MKV/WEBM)
- FFmpeg scene-change based highlight suggestions
- Vertical 9:16 MP4 clips with source audio
- Optional automatic subtitles through faster-whisper

## Important limitations
Ye first working starter hai, full cloud AI product nahi. Highlight finder scene changes aur fallback time sampling use karta hai; ye abhi GTA events ko samajhkar "viral moment" guarantee nahi karta. YouTube URL ingestion intentionally is build mein active nahi hai: pehle apni ya permission wali source video upload karein. Copyrighted GTA footage/music ke rights aur platform rules ka dhyan rakhein.

## Windows PC par setup
1. Python 3.11 install karein (install ke waqt "Add Python to PATH" tick karein).
2. FFmpeg install karein aur `ffmpeg` + `ffprobe` PATH mein add karein.
3. Is folder mein terminal kholein.
4. Commands chalayein:

```bash
py -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
py app.py
```

5. Browser mein `http://127.0.0.1:5000` kholein.

## Subtitles
`faster-whisper` install hone par app local speech transcription karke captions video mein burn karega. Pehli baar model download hoga aur processing slow ho sakti hai. Agar install nahi hai, clip export phir bhi chalega aur result page par warning aayegi.

## Notes
- Large uploads ko process karne mein time lagega.
- Video aapke PC par locally process hoti hai; app ko internet par deploy nahi kiya gaya.
- Production deployment ke liye authentication, job queue, storage limits, malware scanning, secure secrets, and worker hosting add karna zaroori hai.
