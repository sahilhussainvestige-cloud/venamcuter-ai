import os, uuid, subprocess, json, math
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash, jsonify
from werkzeug.utils import secure_filename

BASE = Path(__file__).resolve().parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)
ALLOWED = {".mp4", ".mov", ".mkv", ".webm"}
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-local-dev-key")
app.config["MAX_CONTENT_LENGTH"] = 4 * 1024 * 1024 * 1024

def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)

def ffmpeg_path():
    return "ffmpeg"

def probe_duration(path):
    p = run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", str(path)])
    if p.returncode != 0:
        raise RuntimeError("Video read nahi hui. FFmpeg install/check karo.")
    return float(p.stdout.strip())

def get_scenes(path):
    # Scene-change timestamps are used as one signal; this is a lightweight
    # local heuristic, not a trained GTA/gameplay understanding model.
    p = run(["ffmpeg", "-i", str(path), "-vf",
             "select='gt(scene,0.28)',showinfo", "-an", "-f", "null", "-"])
    times = []
    for line in p.stderr.splitlines():
        if "pts_time:" in line:
            try:
                times.append(float(line.split("pts_time:")[1].split()[0]))
            except Exception:
                pass
    return times

def make_srt_stub(path, out_srt):
    # Optional Whisper transcription. If faster-whisper isn't installed,
    # create a clear placeholder so the rest of the workflow still works.
    try:
        from faster_whisper import WhisperModel
        model = WhisperModel("base", device="cpu", compute_type="int8")
        segments, _ = model.transcribe(str(path), beam_size=3)
        def stamp(t):
            ms = int(round(t * 1000))
            h, ms = divmod(ms, 3600000)
            m, ms = divmod(ms, 60000)
            s, ms = divmod(ms, 1000)
            return f"{h:02}:{m:02}:{s:02},{ms:03}"
        rows = []
        for i, seg in enumerate(segments, 1):
            rows += [str(i), f"{stamp(seg.start)} --> {stamp(seg.end)}", seg.text.strip(), ""]
        out_srt.write_text("\n".join(rows), encoding="utf-8")
        return True
    except Exception:
        out_srt.write_text(
            "1\n00:00:00,000 --> 00:00:03,000\n"
            "Subtitles ke liye faster-whisper install karein.\n",
            encoding="utf-8")
        return False

def choose_highlights(path, duration):
    scenes = get_scenes(path)
    # Select candidate windows around scene changes, plus evenly spaced fallbacks.
    candidates = []
    for t in scenes:
        start = max(0, min(duration - 1, t - 7))
        end = min(duration, start + 28)
        if end - start >= 8:
            candidates.append((start, end))
    if not candidates:
        count = max(1, min(8, int(duration // 45) or 1))
        for i in range(count):
            center = duration * (i + 0.5) / count
            start = max(0, center - 14)
            end = min(duration, start + 28)
            if end - start >= 8:
                candidates.append((start, end))
    # Deduplicate overlapping candidates and cap output.
    selected = []
    for item in candidates:
        if all(abs(item[0] - old[0]) > 12 for old in selected):
            selected.append(item)
        if len(selected) >= 8:
            break
    return selected

def render_clip(src, start, end, out, srt_path=None):
    # Center-crop to 9:16; preserves source audio. Subtitle burn-in is added
    # only if a real Whisper subtitle file was produced.
    vf = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
    if srt_path and srt_path.exists():
        # Escape path for FFmpeg filter syntax.
        srt = str(srt_path).replace("\\", "/").replace(":", r"\\:")
        vf += f",subtitles='{srt}':force_style='FontName=Arial,FontSize=18,Outline=2,Shadow=1,Alignment=2,MarginV=100'"
    cmd = ["ffmpeg", "-y", "-ss", str(start), "-i", str(src), "-t", str(end-start),
           "-vf", vf, "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
           "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(out)]
    p = run(cmd)
    if p.returncode != 0:
        raise RuntimeError("Clip render failed: " + p.stderr[-1200:])

@app.route("/", methods=["GET"])
def home():
    clips = sorted(OUTPUTS.glob("*.mp4"), key=lambda p: p.stat().st_mtime, reverse=True)
    return render_template("index.html", clips=[p.name for p in clips[:12]])

@app.route("/process", methods=["POST"])
def process():
    f = request.files.get("video")
    if not f or not f.filename:
        flash("Pehle apni video file choose karo.")
        return redirect(url_for("home"))
    name = secure_filename(f.filename)
    ext = Path(name).suffix.lower()
    if ext not in ALLOWED:
        flash("MP4, MOV, MKV ya WEBM video upload karo.")
        return redirect(url_for("home"))
    job = uuid.uuid4().hex[:8]
    src = UPLOADS / f"{job}_{name}"
    f.save(src)
    try:
        duration = probe_duration(src)
        if duration < 8:
            raise RuntimeError("Video kam se kam 8 seconds ki honi chahiye.")
        srt = OUTPUTS / f"{job}_captions.srt"
        has_real_subs = make_srt_stub(src, srt)
        highlights = choose_highlights(src, duration)
        made = []
        for i, (start, end) in enumerate(highlights, 1):
            out = OUTPUTS / f"{job}_clip_{i:02}.mp4"
            render_clip(src, start, end, out, srt if has_real_subs else None)
            made.append({"name": out.name, "start": round(start, 1), "end": round(end, 1)})
        return render_template("result.html", clips=made, job=job,
                               subtitle_note=("Auto subtitles generated." if has_real_subs else
                               "Clips ready. Auto subtitles ke liye faster-whisper install karein; abhi SRT placeholder diya hai."))
    except Exception as e:
        flash(str(e))
        return redirect(url_for("home"))

@app.route("/outputs/<path:filename>")
def output_file(filename):
    return send_from_directory(OUTPUTS, filename, as_attachment=True)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
